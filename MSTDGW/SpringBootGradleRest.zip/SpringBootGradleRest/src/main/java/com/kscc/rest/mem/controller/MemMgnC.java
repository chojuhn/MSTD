package com.kscc.rest.mem.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kscc.constant.Constant;
import com.kscc.rest.mem.vo.MemInfoV;

@RestController
public class MemMgnC {
	
	@RequestMapping("/rest/mem/readMemInfo")
	public ArrayList <MemInfoV> readMemInfo(){
		
		MemInfoV memInfo1 = new MemInfoV();
		memInfo1.setName("chojuhn");
		memInfo1.setEmail("j.cho@koreasmartcard.com");
		memInfo1.setPosition("Manager");
		memInfo1.setAge(34);

		MemInfoV memInfo2 = new MemInfoV();
		memInfo2.setName("leehanyong");
		memInfo2.setEmail("leehanyong@koreasmartcard.com");
		memInfo2.setPosition("Manager");
		memInfo2.setAge(40);
		
		MemInfoV memInfo3 = new MemInfoV();
		memInfo3.setName("leechoonghun");
		memInfo3.setEmail("leechoonghun@koreasmartcard.com");
		memInfo3.setPosition("Boss");
		memInfo3.setAge(45);
		
		Constant.memList.add(memInfo1);
		Constant.memList.add(memInfo2);
		Constant.memList.add(memInfo3);
		
		return Constant.memList;
	}
	
	@RequestMapping("/rest/mem/readMemInfoByName/{name}")
	public MemInfoV readMemInfoById(@PathVariable("name") String name ){
		MemInfoV result = null;
		for(int inx = 0 ; inx < Constant.memList.size() ; inx++){
			if(Constant.memList.get(inx).getName().equals(name)){
				result = Constant.memList.get(inx);
				break;
			}
		}
		return result;
	}
	
}
