package com.kscc.constant;

import java.util.ArrayList;

import com.kscc.rest.mem.vo.MemInfoV;

public class Constant {
	public static ArrayList <MemInfoV> memList = new ArrayList <MemInfoV> (); 
}
