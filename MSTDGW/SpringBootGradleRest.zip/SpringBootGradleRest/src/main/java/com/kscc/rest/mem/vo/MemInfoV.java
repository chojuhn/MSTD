package com.kscc.rest.mem.vo;

import lombok.Data;

@Data
public class MemInfoV {
	private String name;
	private String position;
	private String email;
	private int age;
}
