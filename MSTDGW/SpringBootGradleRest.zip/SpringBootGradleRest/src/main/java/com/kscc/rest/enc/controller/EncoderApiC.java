package com.kscc.rest.enc.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/encoder")
public class EncoderApiC {

    /**
     * Encoding to HEX format
     *
     * @param message The string to be encoded in HEX format
     * @return encoded String
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET,produces = {"application/json; charset=UTF-8"})
    @ResponseBody
    public String encodeHexString(@RequestParam("msg") String message) throws Exception {
        byte[] msgBytes = message.getBytes("UTF8");
        String result = "";

//        for(byte value : msgBytes){
//            result += String.format("%02X",value);
//        }
//        return result;
        return message;
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    public String onException(Exception e) throws Exception {
        return e.getMessage();
    }
}